package bd;

import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.Mongo;

public class Database {
	private DataSource dataSource;

	public Database(String jndiname) throws SQLException {
		try {
			dataSource = (DataSource) new InitialContext()
					.lookup("java:comp/env/" + jndiname);
		} catch (NamingException e) {
			// Handle error that it’s not configured in JNDI.
			throw new SQLException(jndiname + " manque dans JNDI : "
					+ e.getMessage());
		}
	}

	public Connection getConnection() throws SQLException {
		return dataSource.getConnection();
	}

	public static Connection getMySQLConnection() throws SQLException {
		Database database = null;
		if (DBStatic.mysql_pooling == false) {
			return (DriverManager.getConnection("jdbc:mysql://" + DBStatic.host
					+ "/" + DBStatic.baseDeDonnees, DBStatic.nomUtilisateur,
					DBStatic.mdp));
		} else {
			if (database == null) {
				database = new Database("jdbc/test");
			}
			return (database.getConnection());
		}
	}

	public static DBCollection getCollectionMongoDB() {
		Mongo m = null;
		try {
			m = new Mongo("localhost");
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		DB db = m.getDB("3I017");
		DBCollection coll = db.getCollection("Messages");
		return coll;
	}
}
