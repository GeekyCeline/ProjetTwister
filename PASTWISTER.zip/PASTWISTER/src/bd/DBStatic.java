package bd;

public class DBStatic {
	public static String host = "localhost";
	public static String nomUtilisateur = "root";
	public static String mdp = "root";
	public static String baseDeDonnees = "test";
	public static boolean mysql_pooling = false;
}
