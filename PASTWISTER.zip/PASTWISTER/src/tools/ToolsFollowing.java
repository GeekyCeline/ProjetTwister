package tools;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

public class ToolsFollowing {

	/** On suit idCible */
	public static void insertionFollowing(int idSource, int idCible,
			Connection c) {
		try {
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			Statement st = c.createStatement();
			String q = "INSERT INTO `Friends`(`source`, `cible`, `timestamp`) VALUES ("
					+ idSource + ", " + idCible + ", " + timestamp + ");";
			ResultSet rs = st.executeQuery(q);
			st.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/** affiche les followers de login */
	public static void afficherFollowings(int id, Connection c) {
		try {
			Statement st = c.createStatement();
			String q = "SELECT * FROM `Friends` WHERE idSource =" + id
					+ ";";
			ResultSet rs = st.executeQuery(q);
			if (rs.next()) {
				String res = "";
				for (int i = 1; i < rs.getFetchSize(); i++) {
					res += rs.getString(i);
				}
				System.out.println(res);
			}
			st.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static boolean dejaSuivi(int idSource, int idCible, Connection c) {
		boolean res = false;
		try {
			Statement st = c.createStatement();
			String q = "SELECT * FROM `Friends` WHERE idSource =" + idSource
					+ "AND idCible =" + idCible + ";";
			ResultSet rs = st.executeQuery(q);
			if (rs.next()) {
				res = true;
			} else {
				res = false;
			}
			st.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}

	/** retire assocation entre login et following */
	public static void removeFollowing(Integer key, String following,
			Connection c) {
		return;
	}
}