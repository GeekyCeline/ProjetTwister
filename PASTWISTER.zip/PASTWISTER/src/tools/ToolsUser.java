package tools;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.Instant;

public class ToolsUser {

	public static int key = 0;

	/** Méthodes à faire dans un autre package ? */
	public static int genereCle() {
		return key++;
	}

	public static boolean userExists(String login, Connection c) {
		boolean res = false;
		try {
			Statement st = c.createStatement();
			String q = "SELECT * FROM Utilisateur WHERE login = '" + login + "';";
			ResultSet rs = st.executeQuery(q);
			if (rs.next()) {
				res = true;
			} else {
				res = false;
			}
			st.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}

	public static boolean checkPassword(String login, String mdp, Connection c) {
		boolean res = false;
		try {
			Statement st = c.createStatement();
			String q = "SELECT * FROM Utilisateur WHERE login =" + login
					+ "AND mdp =" + mdp + ";";
			ResultSet rs = st.executeQuery(q);
			if (rs.next()) {
				res = true;
			} else {
				res = false;
			}
			st.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}

	public static void insertionUtilisateur(String login, String mdp, String nom,
			String prenom, Connection c) {
		try {
			Statement st = c.createStatement();
			String q = "INSERT INTO `Utilisateur`(`id`, `login`, `mdp`, `prenom`, `nom`) VALUES (`id`, "
					+ login + ", " + mdp + ", " + prenom + ", " + nom + ");";
			ResultSet rs = st.executeQuery(q);
			st.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/** A FAIRE DANS TOOLS SESSIONS ? */

	public static boolean userNonConnecte(String login, Connection c) {
		boolean res = false;
		try {
			Statement st = c.createStatement();
			String q = "SELECT * FROM Sessions WHERE login =" + login + ";"; // A vérifier car select sur key plutot ?
			ResultSet rs = st.executeQuery(q);
			if (rs.next()) {
				res = true;
			} else {
				res = false;
			}
			st.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
	
	public static void insertionConnexion(String login, int key, int id, Connection c) {
		try {
			Timestamp debut = new Timestamp(System.currentTimeMillis());
			Timestamp fin = new Timestamp(System.currentTimeMillis()+5*60*1000); // Maintenant +5 minutes
			Statement st = c.createStatement();
			String q = "INSERT INTO `Sessions`(`key`, `idUser`, `connect`, `debut`, `fin`) VALUES ( " + key + ", "
					+ id + ", " + true + ", " + debut + ", " + fin + ");";
			ResultSet rs = st.executeQuery(q);
			st.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void evacuationConnexion(Integer key, Connection c) {
		try {
			Statement st = c.createStatement();
			String q = "DELETE FROM `Sessions` WHERE key = " + key + ";";
			ResultSet rs = st.executeQuery(q);
			st.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
