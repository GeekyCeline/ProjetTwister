package tools;

import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.json.JSONObject;

import bd.Database;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;

public class ToolsMessage {

	public static int idMessage = 0;

	public static void ajouterMessage(Integer idSource, String message) {
		DBCollection coll = Database.getCollectionMongoDB();
		GregorianCalendar calendrier = new GregorianCalendar();
		Date date = calendrier.getTime();
		BasicDBObject obj = new BasicDBObject();
		obj.put("idU", idSource);
		obj.put("idM", idMessage++);
		obj.put("Texte", message);
		obj.put("Date", date);
		List<JSONObject> commentaires = new ArrayList<JSONObject>();
		obj.put("Commentaires", commentaires);
		coll.insert(obj);
	}

	public static boolean messageExists(Integer idMessage) {
		boolean res = false;
		DBCollection coll = Database.getCollectionMongoDB();
		BasicDBObject q = new BasicDBObject();
		q.put("idM", idMessage);
		DBCursor c = coll.find(q);
		while (c.hasNext()) {
			res = true;
		}
		return res;
	}

	public static String afficheMessage(Integer idMessage) {
		String res = "";
		DBCollection coll = Database.getCollectionMongoDB();
		BasicDBObject q = new BasicDBObject();
		q.put("idM", idMessage);
		DBCursor c = coll.find(q);
		while (c.hasNext()) {
			res += c.next();
		}
		return res;
	}

	public static void retirerMessage(Integer idMessage) {
		DBCollection coll = Database.getCollectionMongoDB();
		BasicDBObject q = new BasicDBObject();
		q.put("idM", idMessage);
		coll.remove(q);
	}
}
