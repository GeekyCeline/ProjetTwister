package services;

import java.sql.Connection;
import java.sql.SQLException;

import org.json.JSONException;
import org.json.JSONObject;

import tools.ToolsUser;
import ErrorJSON.ErreursJSON;
import bd.Database;

public class ServiceUser {

	

	/***
	 * Création d'un utilisateur
	 * 
	 * @param login
	 *            id sous lequel l'utilisateur va s'identifier
	 * @param mdp
	 *            mot de passe
	 * @param pseudo
	 *            nom affiché
	 * @param nom
	 * @param prenom
	 * @param email
	 * @return JSONObject avec code erreur et message descriptif
	 */
	public static JSONObject creationUtilisateur(String login, String mdp,
			String nom, String prenom) {
		Connection c=null;
		try{
		 c = Database.getMySQLConnection();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
		JSONObject o = new JSONObject();
		try {
			if ((login == null) || (mdp == null) || (nom == null)
					|| (prenom == null)) {
				o = ErreursJSON
						.serviceRefused("Parametre(s) invalide(s)", "-1");
				return o;
			} else {
				if (!tools.ToolsUser.userExists(login, c)) {
					o = ErreursJSON.serviceAccepted("OK", "1");
					ToolsUser.insertionUtilisateur(login, mdp, nom, prenom, c);
				} else {
					o = ErreursJSON
							.serviceRefused("Le login existe déjà", "-1");
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return o;
	}

	/***
	 * Méthode de connexion à un compte présent dans la BD
	 * 
	 * @param login
	 *            id du compte
	 * @param mdp
	 *            mot de passe du compte
	 * @return JSONObject avec code erreur et message descriptif
	 */
	public static JSONObject login(String login, String mdp, int id) {
		JSONObject o = new JSONObject();
		Connection c=null;
		try{
			c = Database.getMySQLConnection();
			}
			catch(SQLException e){
				e.printStackTrace();
			}
			
		try {
			if (login == null || mdp == null) {
				o = ErreursJSON
						.serviceRefused("Parametre(s) invalide(s)", "-1");
			} else {
				if (!ToolsUser.userExists(login, c)) {
					o = ErreursJSON.serviceRefused("Ce login n'existe pas",
							"-1");
				} else {
					if (!ToolsUser.checkPassword(login, mdp, c)) {
						o = ErreursJSON.serviceRefused(
								"Mot de passe incorrect", "-2");
					} else {
						if (ToolsUser.userNonConnecte(login, c)) {
							int key = ToolsUser.genereCle();
							o = ErreursJSON
									.serviceAccepted("OK", "key :" + key);
							ToolsUser.insertionConnexion(login, key, id, c);

						} else {
							o = ErreursJSON
									.serviceRefused(
											"Veuillez vous déconnecter de votre autre appareil",
											"-3");
						}
					}
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return o;
	}

	public static JSONObject logout(Integer key) {
		Connection c=null;
		try{
			 c = Database.getMySQLConnection();
			}
			catch(SQLException e){
				e.printStackTrace();
			}
			
		JSONObject o = new JSONObject();
		if (key == null) {
			o = ErreursJSON.serviceRefused("Parametre(s) invalide(s)", "-1");
		} else {
			ToolsUser.evacuationConnexion(key, c);
			try {
				o = ErreursJSON.serviceAccepted("Vous êtes déconnecté", "1");
			} catch (JSONException e) {
				o = ErreursJSON.serviceRefused("Restez connecté(e)", "100");
			}
		}
		return o;
	}
}