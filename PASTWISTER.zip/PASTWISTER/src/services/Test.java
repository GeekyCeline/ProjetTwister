package services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.json.JSONObject;

import tools.ToolsMessage;
import tools.ToolsUser;
import bd.Database;

public class Test {

	public static void main(String[] args) {
		JSONObject o;
		String login = "B";
		String victime = "A";

		 o = ServiceUser.creationUtilisateur("HarryP", "MdP", "HPotter",
		 "Potter");
		 System.out.println("Fin main " + o.toString());

//		try {
//			Class.forName("com.mysql.jdbc.Driver");
//			Connection co = Database.getMySQLConnection();
//			
//			String log="HP";
//			String query = "SELECT * FROM Utilisateur WHERE login = 'HP';";
//			Statement st = co.createStatement();
//			ResultSet rs = st.executeQuery(query);
//			while (rs.next()) {
//				for (int i = 1; i < 6; i++) {
//					System.out.println(rs.getString(i));
//				}
//			}
//			System.out.println(ToolsUser.userExists(log, co));
//			st.close();
//			co.close();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		
		System.out.println("FIN MAIN");

		// o = ServiceUser.login("A", "mdpDe");
		// System.out.println(o.toString());

		// String l = null;
		// o = ServiceUser.logout(l);
		// System.out.println(o.toString());

		// o = ServiceVictimes.ajouterSuiveur(login, victime);
		// System.out.println(o.toString());
		// o = ServiceVictimes.afficherFollowers(login);
		// System.out.println(o.toString());
		// o = ServiceVictimes.effacerVictime(login, victime);
		// System.out.println(o.toString());

	}
}
