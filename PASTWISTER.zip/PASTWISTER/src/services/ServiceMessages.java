package services;

import java.sql.Connection;

import org.json.JSONException;
import org.json.JSONObject;

import tools.ToolsMessage;
import ErrorJSON.ErreursJSON;
import bd.Database;

public class ServiceMessages {
	
	public static Connection c = Database.getMySQLConnection();
	
	public static JSONObject newMessage(Integer key, String message) {
		JSONObject o = new JSONObject();
		if (key == null || message == null) {
			o = ErreursJSON.serviceRefused("Paramètre(s) invalide(s)", "-1");
		} else {
			if (message == "") {
				o = ErreursJSON.serviceRefused("Le message est vide", "-1");
			} else {
				ToolsMessage.ajouterMessage(key, message);
				try {
					o = ErreursJSON.serviceAccepted(
							"Votre message a été posté", "1");
				} catch (JSONException e) {
					o = ErreursJSON.serviceRefused("Bug", "100");
				}
			}
		}
		return o;
	}
	
	public static JSONObject afficherMessage(Integer idMessage) {
		JSONObject o = new JSONObject();
		String res = "";
		if (idMessage == null) {
			o = ErreursJSON.serviceRefused("Paramètre(s) invalide(s)", "-1");
		} else {
			if (!ToolsMessage.messageExists(idMessage)) {
				o = ErreursJSON.serviceRefused("Le message n'existe pas",
						"-1");
			} else {
				res = ToolsMessage.afficheMessage(idMessage);
				try {
					o = ErreursJSON.serviceAccepted(
							"Message affiché", "1");
				} catch (JSONException e) {
					o = ErreursJSON.serviceRefused("Bug", "100");
				}
			}
		}
		System.out.println(res);
		return o;
	}

	public static JSONObject deleteMessage(Integer key, Integer idMessage) {
		JSONObject o = new JSONObject();
		if (key == null || idMessage == null) {
			o = ErreursJSON.serviceRefused("Paramètre(s) invalide(s)", "-1");
		} else {
			if (!ToolsMessage.messageExists(idMessage)) {
				o = ErreursJSON.serviceRefused("Le message n'existe pas",
						"-1");
			} else {
				ToolsMessage.retirerMessage(idMessage);
				try {
					o = ErreursJSON.serviceAccepted(
							"Votre message a été supprimé", "1");
				} catch (JSONException e) {
					o = ErreursJSON.serviceRefused("Bug", "100");
				}
			}
		}
		return o;
	}
}
