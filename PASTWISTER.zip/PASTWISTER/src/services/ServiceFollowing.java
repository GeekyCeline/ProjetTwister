package services;

import java.sql.Connection;

import org.json.JSONException;
import org.json.JSONObject;

import ErrorJSON.ErreursJSON;
import bd.Database;

public class ServiceFollowing {

	public static Connection c = Database.getMySQLConnection();

	public static JSONObject ajouterFollowing(int idSource, int idCible,
			String loginCible) {
		JSONObject o = new JSONObject();
		if ((idCible == 0) || (idCible == 0) || (loginCible == null)) {
			o = ErreursJSON.serviceRefused("Parametre(s) invalide(s)", "-1");
		} else {
			if (!tools.ToolsUser.userExists(loginCible, c)) {
				o = ErreursJSON
						.serviceRefused(
								"La personne que vous voulez suivre n'existe pas",
								"-1");
			} else {
				if (tools.ToolsFollowing.dejaSuivi(idSource, idCible, c)) {
					o = ErreursJSON.serviceRefused(
							"Vous suivez déjà cette personne", "-1");
				} else {
					tools.ToolsFollowing.insertionFollowing(idSource, idCible,
							c);
					try {
						o = ErreursJSON.serviceAccepted(
								"Vous suivez à présent " + idCible, "1");
					} catch (JSONException e) {
						o = ErreursJSON.serviceRefused("Bug", "100");
					}
				}
			}
		}
		return o;
	}

	public static JSONObject afficherFollowings(int id) {
		JSONObject o = new JSONObject();
		if (id == 0) {
			o = ErreursJSON.serviceRefused("Parametre(s) invalide(s)", "-1");
		} else {
			tools.ToolsFollowing.afficherFollowings(id, c);
			try {
				o = ErreursJSON.serviceAccepted(
						"Voici les personnes que vous suivez cher " + id, "1");
			} catch (JSONException e) {
				o = ErreursJSON.serviceRefused("Bug", "100");
			}
		}
		return o;
	}

	public static JSONObject removeFollowing(Integer key, String following) {
		JSONObject o = new JSONObject();
		if (key == null || following == null) {
			o = ErreursJSON.serviceRefused("Parametre(s) invalide(s)", "-1");
		} else {
			if (!tools.ToolsUser.userExists(following, c)) {
				o = ErreursJSON.serviceRefused(following + " n'existe pas",
						"-1");
			} else {
				if (!tools.ToolsFollowing.dejaSuivi(key, following, c)) {
					o = ErreursJSON.serviceRefused("Vous ne suivez pas "
							+ following, "-1");
				} else {
					tools.ToolsFollowing.removeFollowing(key, following, c);
					try {
						o = ErreursJSON
								.serviceAccepted(
										following
												+ " n'est plus dans la liste des personnnes que vous suivez",
										"1");
					} catch (JSONException e) {
						o = ErreursJSON.serviceRefused("Bug", "100");
					}
				}
			}
		}
		return o;
	}

}
